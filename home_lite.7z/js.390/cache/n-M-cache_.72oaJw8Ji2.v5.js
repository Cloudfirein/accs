let m2CacheVERSION ="1.7.0"
console.warn(" Source:Running M-CAHE "+m2CacheVERSION+""),
document.getElementById("w37").innerHTML="Your Version Is <b>"+m2CacheVERSION+"</b>"

const unsubscribe2 = firebase.auth().onAuthStateChanged((user) => {
                    if (user) {
                        console.log(user),                        getuserInfoRealtime(user.uid)
                        if (user.email == 'beta@admin.cfi') {
                        document.getElementById("BRDC_EN").style.display="block"
                           M.toast({
                            html: `ELIGABLE FOR BRDC UPGRADE <a href='#Nav' onclick='openAccsNav()' style='color:white;'>Upgrade ></a>`,
                            classes: "orange"
                        }) 
}
if (user.email == 'adhil@cloudfirein.rf.gd') {
                        document.getElementById("BRDC_EN").style.display="block"
                           M.toast({
                            html: `ELIGABLE FOR BRDC UPGRADE <a href='#Nav' onclick='openAccsNav()' style='color:white;'>Upgrade ></a>`,
                            classes: "orange"
                        }) 
}
                        } 
                        if(user.email == 'muhammedadhil856@gmail.com') {document.getElementById("BRDC_EN").style.display="block",M.toast({html: `ELIGABLE FOR BRDC UPGRADE <a href='#Nav' onclick='openAccsNav()' style='color:white;'>Upgrade ></a>`,classes: "orange"})}          
                        if(user.email == 'supperaccount@cfi.com') {document.getElementById("BRDC_EN").style.display="block",M.toast({html: `WELCOME SUPPER ACCOUNT <a href='#Nav' onclick='openAccsNav()' style='color:white;'>Upgrade IT></a>`,classes: "orange"})}  
                                            
                        
                      
                });        
                

                
function BRAIN_RELAY_DEVELOPER_CONSOLE_2023_JULY() {
  
                        
document.getElementById("BRDC_EN").style.display="none",                    document.getElementById("devoption1").style.display=""+devmodeAC+"",                           document.getElementById("devoption1").style.display=""+devmodeAC+""
document.getElementById("devoption2").style.display=""+devmodeAC+""
document.getElementById("devoption3").style.display=""+devmodeAC+""
document.getElementById("devoption4").style.display=""+devmodeAC+""
document.getElementById("devoption5").style.display=""+devmodeAC+""
document.getElementById("devoption6").style.display=""+devmodeAC+""
document.getElementById("devoption7").style.display=""+devmodeAC+""
document.getElementById("devoption8").style.display=""+devmodeAC+""
document.getElementById("devoption9").style.display=""+devmodeAC+""
document.getElementById("switch-3").style.display=""+devmodeAC+""
document.getElementById("w22").style.display=""+devmodeAC+""
document.getElementById("w23").style.display=""+devmodeAC+""
document.getElementById("w24").style.display=""+devmodeAC+""
document.getElementById("tta").style.display=""+devmodeAC+""
document.getElementById("ttb").style.display=""+devmodeAC+"", document.getElementById("w31").style.display=""+devmodeAC+"", document.getElementById("w32").style.display=""+devmodeAC+"",  
document.getElementById("w34").style.display=""+devmodeAC+"",
document.getElementById("w35").style.display=""+devmodeAC+""
document.getElementById("BR_ORG_GO").style.display=""+devmodeAC+""
                          M.toast({
                            html: `YOU ARE UPGRADED WITH DEVELOPER OPTIONS. <a href='#modal99' class='modal-trigger'>Go></a>`,
                            classes: "orange"
                        })  
                        const userDocRefLA = firebase.firestore().collection('users').doc(firebase.auth().currentUser.uid);                                    userDocRefLA.update({ch25:"UPGRADED TO BRDC."})
}
function BRAIN_RELAY_DEVELOPER_CONSOLE_2023_JULY_DISABLE() {    document.getElementById("BRDC_EN").style.display="block"
    const devmodeAC ="none"
}
document.getElementById("w36").innerHTML="This is your last confirmation to Delete Account so do at your own risk!.Once deleted a account you can't undo this action.Later you can create a new account with this email.But some new account creation is not supported.If you only want to disable your account so you can contact us to disable your account.we take necessary actions."
document.getElementById("w40").innerHTML="Thank You For Your Patience To Check It."

const htdin = document.getElementById('htd');
let itemsArrayHtd = localStorage.getItem('htd') ?
JSON.parse(localStorage.getItem('htd')) : [];

itemsArrayHtd.forEach(addTaskHtd);
function addTaskHtd(textHtd){
 const liHtd = document.getElementById("headtextLocal");
  const liHtdCs = document.getElementById("headtextLocalCs");
 liHtd.textContent = textHtd;
 liHtdCs.textContent = textHtd;
 //u2l.appendChild(li);
}
function addheadtext(){
  itemsArrayHtd.push(htdin.value);
  localStorage.setItem('htd', JSON.stringify(itemsArrayHtd));
  addTaskHtd(htdin.value);
  
                    document.getElementById("accsNav").style.display="none"
                    document.getElementById("m3").style.display="block"
                    document.getElementById("w29").style.display="inline"
    document.getElementById("m4").style.display="none"
  const userDocRefLA = firebase.firestore().collection('users').doc(firebase.auth().currentUser.uid);                                    userDocRefLA.update({ch25:"HEAD TEXT ADDED"})
  Swal.fire({
  icon: 'success',
  title: "Head Text Added ",
    text: 'Go To SideNav For Deleting This Action. This action doesnt have any server support so while you logging into another device using this account , the Head Text doesnt transmitted.',
   })
}
document.getElementById("TERMPOLICY").innerHTML="<div id='fwelco'> <div id='m1'><h4 id='m2'><a href='#BacktoNav' id='closefwelcoFromNav' onclick='conToAccs()' style='color:#ff9595;font-size:25px;' class='ico4423' >arrow_back</a><a  href='#modal28' id='closefwelcoFromBoot'  style='color:#ff9595;font-size:25px;' class='ico4423 modal-trigger'>arrow_back</a><img src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' width='25px' height='25px'alt='Accs-Logo'>ACCS LITe</h4></div></br></br></br></br><center><img id='headimgLocal' src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' width='75px' height='75px'alt='AL'><h1>Welcome To <tq>ACCS&reg</tq></h1><div id='fwelcoCONTENT'>😐💔(SOMETHING WENT WRONG)</div><b id='s1'>By Continuing you agreed to our all mentioned terms and our privacy policy.</b></br></br><button class='btn blue darken-2' onclick='conToAccs()' id='conToAccsText'>Accept And Continue.</button></br></br><p id='ver4'>🥺</p></div>"

document.getElementById("fwelcoCONTENT").innerHTML="<b class='left'>Features</br>•Change theme from Accs Menu.</br>•Custimaze welcome Prompt</br>•Custimaze head text.</br>•Edit account information without any delay.</br>•Custimaze welcome name.</br>•enter manual theme codes provided by ACCS.</br>•Change Profile picture.</br>•Both CLOUDSHARE account can be used at a time.</br>•Account deletion.</br>•link with any organisation that run by you (This feature shows the mini icon of your organization and a link its website on your username)</br>•Account Verification (a verified badge on account and it's uid)</br>•Option to recover password.</br>•Option to reset account data at anytime.*</br></br></b></br>Accs is the global binder of all Cloud Fire International's Platforms.</br></br>You must accept our terms of uses.</br></br>ACCS&reg is a registered trademark of Cloud Fire International. modification or using the source code is illegal and prohibited.</br></br>CFI&#8482; is a registered short trademark of Cloud Fire International to represent in ACCS&reg or other Cloud Fire International Platforms.</br></br><tq>ACCS-BINDER∞</tq> is sub-system of ACCS&reg and all of it's rights reserved by Cloud Fire International&#8482;.</br></br>The logos of ACCS&reg and Cloud Fire International&#8482; is placed by it's own registered servers with access licence.</br></br>Third-party services has already in used by ACCS&reg, but we didn't share any of your data with them.</br></br>we chronologically collect your logs to ACCS&reg , for checking the unusual behaviour or traffic from your account or browser.</br></br>This site(ACCS&reg) uses cookies to deliver you a better experience, you must be agreed that we to being used.</br></br>In this site ACCS&reg are is normally represented as <tq>ACCS OR ACCS LITe.</br></br>By using ACCS it's influence your Cloud Fire International Account System.it may affect your account.</br></br></tq>ACCS LITe is a lite weight and powerful version of ACCS that builds by Cloud Fire International&#8482;. </br></br>You can ask/request to delete your account and data's related to your account at anytime.</br></br>Hoping you a happy experience with <tq>ACCS / ACCS LITe</tq></br></br>"
document.getElementById("st1").innerHTML="<b>Server Base : 388/387-JS/CSS(INTER)</b>"
document.getElementById("fwelco").style.display="none"
document.getElementById("ver4").innerHTML=""+accsver+""

