document.getElementById("snasMORE").style.display="none"
document.getElementById("snasMORE").innerHTML=" <div id='m1'><h4 id='m2'><a  href='#WE' id='snas1' onclick='closeSNAS()' style='color:#ff9595;font-size:25px;' class='ico4423'>arrow_back</a><img src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' width='25px' height='25px'alt='Accs-Logo'>ACCS LITe</h4></div></br></br></br></br><center><img id='headimgLocal' src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' width='75px' height='75px'alt='AL'><h5>SOCIAL NETWORK ACCOUNT SYSTEM</h5><p>DATA AVAILABLE SOON</p>"
function openSNAS() {
    document.getElementById("suclog").style.display="none"
    document.getElementById("snasMORE").style.display="block"
    document.getElementById("modal27").style.display="none"
    document.getElementById("snas2").style.display="none"
}
function closeSNAS() {
    document.getElementById("suclog").style.display="block"
    document.getElementById("snasMORE").style.display="none"
    document.getElementById("snas2").style.display="block"
}
