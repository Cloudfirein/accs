console.warn("IMPORTING:- J CACHE ∞")
document.getElementById("w39").innerHTML="Your Version Is <b>1.13.0",
document.getElementById("lpage").style.display="none"
//Write Only allowed after this
document.getElementById("logoutpage").innerHTML="<div class='modal' id='modal8'><div class='modal-content'><center id='logoutPRE'><img src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' width='75px' height='75px'alt='Logo'><h4>Confirm Logout</h4><p>This Action Cannot Be Undo, Are you sure to logout?</p><button id='cslogoutbtn' class='btn red darken-2' onclick='cslogout()'>Logout CLOUDSHARE</button></br><button id='cfilogoutbtn' class='btn red darken-2' onclick='cfilogout()'>Logout Cloud Fire</button></center></br><tq>ACCS BINDER ∞</tq><a href='#both' onclick='bothlogout()' class='btn green darken-2' id='devoption8'>Logout Both Accounts(INTERNAL)</a></div></div>"


document.getElementById("cfilogoutbtn").style.display="none"

document.getElementById("cslogoutbtn").style.display="none"

document.getElementById("csshowbody").style.display="none"

document.getElementById("cfishowbody").style.display="none"
document.getElementById("m6").style.display="none"
document.getElementById("m7").style.display="none"
document.getElementById("m8").style.display="none"
  
document.getElementById("closecscrFromSuclog").style.display= "none"

document.getElementById("cscreatewindow").style.display="none"

document.getElementById("suclog").style.display="none"


document.getElementById("modalspace2").innerHTML="<div class='modal' id='modal15'><div class='modal-content'><img src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' alt='ACCS' width='75px' height='75px'><h4>Account Settings</h4><button class='btn yellow darken-2'><a class='modal-trigger' href='#modal3'>Edit Common Info</a></button></br></br><button class='btn grey darken-2'><a class='modal-trigger' href='#modal13' onclick='restaccountFromCfi()'>Reset Account</a></button></br> </br><button class='btn green darken-2'><a class='modal-trigger' href='#modal23'>More</a></button></br><tq>ACCS BINDER ∞</tq></div></div>"

document.getElementById("moresettings").innerHTML="<div class='modal' id='modal23'><div class='modal-content' ><center><img src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' alt='Logo' width='75px' width='75px'><h4>More Settings</h4></br><button  class='btn blue darken-2'><a class='modal-trigger' href='#modal22'>User Tags</a></button></br></br><button  class='btn green darken-2'><a class='modal-trigger' href='#modal24'>User Name</a></button></br></br>looking for reset your password.?</br>Try logout and click the login button now you will be see the reset password option</br><tq>ACCS BINDER ∞</tq></center></div></div>"

document.getElementById("accsprime").innerHTML="<div class='modal' id='modal16'><div class='modal-content' id='accsPrimeInt'><img src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' width='75px' height='75px'alt='Logo'><h4><tq>ACCS PRIME CONTROL <b style='font-sifont-size:6px;'></b></tq></h4></br><button class='btn red darken-2'><a href='#modal8' class='modal-trigger'>Logout</a></button></br></br><button class='btn blue darken-2'><a href='#modal17' class='modal-trigger'>Profile Pictures</a></button></br></br><button class='btn #ff7300 darken-2'><a href='#modal25' class='modal-trigger'>Change Theme</a></button></br></br><button class='btn blue darken-2'><a href='#modal18' class='modal-trigger'>Delete Accounts</a></button></br></br><button class='btn yellow darken-2 modal-trigger' id='devoption9' href='#modal15'>Ac Settings(INTERNAL) </button><p><button class='btn orange darken-2' onclick='upgrade64BIT_1()' id='64BIT_STATUS'>UPGRADE TO 64BIT</button></p><p><tq>ACCS BINDER ∞</tq></p></div></div><div class='modal' id='modal27'><div class='modal-content'><center><h1><tq>ACCS</tq></br><tq></tq></h1>(+∞+)</br>Accs&reg is the global binder of Cloud Fire International.</br>The fastest realtime account facility on beta test, every moment ACCS was building more better.</br>In our future plan make this as a SOCIAL NETWORK ACCOUNT SYSTEM.(SNAS&reg).</br>Your current account and it's information also been transferred into the SOCIAL NETWORK ACCOUNT SYSTEM without any consent notice because we reserved this right, it mentioned in our privacy policy and TERM POLICY.</br>SOCIAL NETWORK ACCOUNT SYSTEM is a UNIVERSAL SOCIAL MEDIA PROTOCOL (USMP&reg) that a has capability to share your account on multiple SOCIAL MEDIA PLATFORMS without creating a actual new account.</br></br><button class='btn'onclick='openTERMPOLICY()'>Read TERM POLICY</button></br></br><button class='btn'onclick='openSNAS()' id='snas2'>ABOUT SNAS&reg</button><div data-theme='cfi_area2524' class='Themeswitch' id='switch-4'>DISABLE ACCS&reg(CFI)</div><button id='devoption3' onclick='closesuclog()' class='btn red darken-2'>Close suclog</button></br></br><tq>ACCS BINDER ∞</tq></center></div></div>"

document.getElementById("themepage").innerHTML="<div class='modal' id='modal25'><div class='modal-content'><center><img src='img.384/8315419563691929000021718307847389263000049577019355394380000.webp' width='75px' height='75px'alt='Logo'><section id='cfi_area_the'><h4>Change <tq>ACCS</tq> Theme ß</h4><p>Select a theme as per your choice.<p id='currenttheme'></p> </p><div data-theme='light' class='Themeswitch' id='switch-1' onclick='thlisw()'>Royal</div>      <div data-theme='dark' class='Themeswitch' id='switch-2' onclick='thdasw()'>Dark</div><div data-theme='lightorg' class='Themeswitch' id='switch-4' >Light </div>while switching between themes take a break atleast for 3s to server to process your data. </section></center></div></div>"

function opencscr() {
    document.getElementById("cscreatewindow").style.display="block"
    

 document.getElementById("accslogin").style.display="none"
}     
function opensuclog() {
    document.getElementById("suclog").style.display="block"
    document.getElementById("accslogin").style.display="none"
}     
function closesuclog() {
    document.getElementById("suclog").style.display="none"
    document.getElementById("accslogin").style.display="block"
}
function opencscrFromSuclog() {
   
    document.getElementById("cscreatewindow").style.display="block"
    
document.getElementById("closecscrFromSuclog").style.display="block"   

document.getElementById("closecscrFromMain").style.display="none"
 document.getElementById("suclog").style.display="none"
}     

  function closecscrFromSuclog() {
    document.getElementById("cscreatewindow").style.display="none"
document.getElementById("suclog").style.display="block"    
}
function closecscr() {
    document.getElementById("cscreatewindow").style.display="none"
document.getElementById("accslogin").style.display="block"    
} document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.modal');
    var instances = M.Modal.init(elems);
  });


function cslogout() {
    firebasee.auth().signOut()
    
document.getElementById("cslogoutbtn").style.display="none"
                    Swal.fire({
                        icon: "info",
                        title: "Thanks For Using ACCS-LITE ",
                        text: "You are successfully Logouted from your CloudShare Account",

                    })

                    M.toast({
                        html: `Logged Out<a href='#modal7' class='modal-trigger'>Login Again></a>`,
                        classes: "red"
                    })
document.getElementById("csshowbody").style.display="none"  

document.getElementById("modal8").style.display="none"  

document.getElementById("updateProPrimeCs").style.display="none"
document.getElementById("deleteCs").style.display="none"

document.getElementById("proimgCs").src="https://firebasestorage.googleapis.com/v0/b/cloudfirein-pub-storege-1.appspot.com/o/users%2FGA39mDtx7tQXMVtxoaoHWboetcD3%2F724043812846151300000398067274810471900000395374026866242000000?alt=media&token=f2201fc2-6554-4995-8dfb-329f7de83b8e"
             document.getElementById("cslogcheck").style.display="block"    
 document.title="ACCS CS"
               }  
               
 function cfilogout() {
    firebase.auth().signOut()
document.getElementById("cfilogoutbtn").style.display="none"
                    Swal.fire({
                        icon: "info",
                        title: "Thanks For Using ACCS-LITE ",
                        text: "You are successfully Logouted from your Cloud Fire Account",

                    })

                    M.toast({
                        html: `Logged Out<a href='#modal6' class='modal-trigger'>Login Again></a>`,
                        classes: "red"
                    })
document.getElementById("cfishowbody").style.display="none"  

document.getElementById("modal8").style.display="none"  

document.getElementById("deleteCfi").style.display="none"
document.getElementById("BR_ORG_GO").style.display="none"
document.getElementById("m6").style.display="none"
document.getElementById("m7").style.display="none"
document.getElementById("m8").style.display="none"
document.getElementById("updateProPrimeCfi").style.display="none"

document.getElementById("cfilogsta2").innerHTML=" Logouted,Just Now."
document.getElementById("BRDC_EN").style.display="none"
             document.getElementById("cfilogcheck").style.display="block"    
 document.title="ACCS - "
 document.getElementById("proimg").src="img.384/favicon.ico.webp"
 document.getElementById("m5").innerHTML="<tq>ACCS</tq> User", document.getElementById("proimg3").src="img.384/favicon.ico.webp"

//localStorage.removeItem('theme');
//localStorage.clear()
//localStorage.removeItem('style');
 document.getElementById("unameshow").innerHTML="There 👋"
               }                 
               


function uidshowFromCs() {
     document.getElementById("uidshowCfi").style.display="none"
     
 document.getElementById("uidshowCs").style.display="block"    
     
document.getElementById("uidshowH1").innerHTML="UID CS"     

document.getElementById("uidDesc").innerHTML="This is your permanent UID for account Cs activities, if you encountered any problems or bugs in ACCS or Cloud Fire International's other platforms contact us with this UID. please kept the UID secretly.."
}
 function restpassFromCs() {
     document.getElementById("restpassCfiCon").style.display="none"
document.getElementById("restpassH1").innerHTML="Reset Password For Cshare"
 M.toast({
                        html: `CFIR:RestPass Running For Cshare`,
                        classes: "blue"
                    })
 }
 function forgotPassCs() {
document.getElementById("modal11").style.display = "none"

document.getElementById("modal11").style.opacity="100%"
 document.getElementById("lpage").style.display="flex"
                    const email = document.getElementById("emailForPassCs").value
                    firebasee.auth().sendPasswordResetEmail(email)
                        .then(() => {
 document.getElementById("lpage").style.display="none"                       
                            Swal.fire({
                                icon: "success",
                                title: "Reset Link Sent Successfull",
                                text: "Successfully Password Reset Link Send To " + email + ", Pls Check Your Mail App.",

                            })
  
     document.getElementById("cslogsta2").innerHTML="Requested For Account Password Reset,Just Now"     
                       document.getElementById("modal11").style.display = "none"
                        })
                        .catch((error) => {
                            //document.getElementById("error").innerHTML = //error.message
   document.getElementById("lpage").style.display="none"                         
                            Swal.fire({
                                icon: "error",
                                title: "Sorry We Cant Proceed This Action At The Moment.",
                                text: error.message,

                            })
    document.getElementById("cslogsta2").innerHTML="Request For Account Password Reset Failed,Just Now"
                      document.getElementById("modal11").style.display = "none"
                        });

                }
                
                
             function restpassFromCfi() {
     document.getElementById("restpassCsCon").style.display="none"
document.getElementById("restpassH1").innerHTML="Reset Password For Cloud Fire"
 M.toast({
                        html: `CFIR:RestPass Running For Cloud Fire`,
                        classes: "blue"
                    })
 }
 function forgotPass() {
document.getElementById("modal11").style.display = "none"


 document.getElementById("lpage").style.display="flex"
                    const email = document.getElementById("emailForPass").value
                    firebase.auth().sendPasswordResetEmail(email)
                        .then(() => {
 document.getElementById("lpage").style.display="none"                       
                            Swal.fire({
                                icon: "success",
                                title: "Reset Link Sent Successfull",
                                text: "Successfully Password Reset Link Send To " + email + ", Pls Check Your Mail App.",

                            })

     document.getElementById("cfilogsta2").innerHTML="Requested For Account Password Reset,Just Now"     
     document.getElementById("cfilogsta1").innerHTML="Requested For Account Password Reset,Just Now"     
                       document.getElementById("modal11").style.display = "none"
                        })
                        .catch((error) => {
                            //document.getElementById("error").innerHTML = //error.message
   document.getElementById("lpage").style.display="none"                         
                            Swal.fire({
                                icon: "error",
                                title: "Sorry We Cant Proceed This Action At The Moment.",
                                text: error.message,

                            })
    document.getElementById("cfilogsta2").innerHTML="Request For Account Password Reset Failed,Just Now"
    
document.getElementById("cfilogsta1").innerHTML="Request For Account Password Reset Failed,Just Now"    
                      document.getElementById("modal11").style.display = "none"
                        });

                }  
                
function restaccountFromCs() {
  document.getElementById("restaccountCfiCon").style.display = "none"
 
 document.getElementById("restaccountCsCon").style.display = "flex"
  document.getElementById("restaccountH1").innerHTML="Reset Account Data (CloudShare)"
   M.toast({
                        html: `CFIR:RestAccount Running For Cshare`,
                        classes: "blue"
                    })
}


async function loginRe(e) {
                    e.preventDefault()
                    const email = document.querySelector('#loginEmailRe')
                    const password = document.querySelector('#loginPasswordRe')
                    const rname = document.getElementById('loginNameRe').value
                 document.getElementById("lpage").style.display = "flex"  

 document.getElementById("modal13").style.display = "none"                     

                    try {
                        const result = await firebase.auth().signInWithEmailAndPassword(email.value, password.value)
                        await result.user.updateProfile({
                            displayName: "" + rname + ""

                        })
                        createUserCollection(result.user)
                        result.user.sendEmailVerification()
                        M.toast({
                            html: `All Data Now Will Reseted And Welcome, ${result.user.email}`,
                            classes: "green"
                        })
                        document.getElementById("lpage").style.display = "none"
                        Swal.fire({
                            icon: "success",
                            title: "Reseted",
                            text: "Your all data in ACCS was reseted to defualt , not include your profile picture.",

                        })
                        console.log(result)}                                                   catch (err){document.getElementById("lpage").style.display = "none";Swal.fire({ico: "error",title: "Sorry We Cant Reset Your Account At The Moment.",text: err,});                   console.log(err),M.toast({html: err.message,classes: "red"})}email.value = "e";password.value = "";}

async function loginReCs(e) {
                    e.preventDefault()
                    const email = document.querySelector('#loginEmailReCs')
                    const password = document.querySelector('#loginPasswordReCs')
                    const rname = document.getElementById('loginNameReCs').value
                    document.getElementById("lpage").style.display = "flex"
  document.getElementById("modal13").style.display = "none"                  
                    try {
                        const result = await firebasee.auth().signInWithEmailAndPassword(email.value, password.value)
                        await result.user.updateProfile({
                            displayName: "" + rname + ""

                        })
                        //createUserCollection(result.user)
                        result.user.sendEmailVerification()
                        M.toast({
                            html: `All Data Now Will Reseted And Welcome, ${result.user.email}`,
                            classes: "green"
                        })
                        Swal.fire({
                            icon: "success",
                            title: "Reseted",
                            text: "Your all data in ACCS was reseted to defualt , not include your profile picture.",

                        })
const userDocRefLA = firebase.firestore().collection('users').doc(firebase.auth().currentUser.uid);                                    userDocRefLA.update({ch25:"ACCOUNT DATA RESETED"})
                        
document.getElementById("lpage").style.display = "none"
                        
        document.getElementById("cslogsta2").innerHTML="Account Data Reseted,Just Now"                
                        console.log(result)
                        //location.replace("home.html")
                    } catch (err) {
                    document.getElementById("lpage").style.display = "none"
                        Swal.fire({
                            icon: "error",
                            title: "Sorry We Cant Reset Your Account At The Moment.",
                            text: err,

                        })
    document.getElementById("cslogsta2").innerHTML="Request For Account Data Reset Failed, Just Now"                    
                        
                        console.log(err)
                        M.toast({
                            html: err.message,
                            classes: "red"
                        })
                    }
                    email.value = "😩🚶"
                    password.value = ""
                    
                }
function uploadImage(e) {
     document.getElementById("lpage").style.display="block"              
      console.log(e.target.files[0]),
      
      document.getElementById("lpage").style.display="block", 
      
                        Swal.fire({
                            icon: 'info',
                            title: 'Uploading Your Profile',
                            text: 'Updating your profile please wait a while.. ',
                        })
                 
                    const uid = firebase.auth().currentUser.uid
                    const fileRef = firebase.storage().ref().child(`/users/${uid}/profile`)
                    const uploadTask = fileRef.put(e.target.files[0])
                    uploadTask.on('state_changed',
                        (snapshot) => {

                            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;

                            //icon:'info',
                            //title:'Uploading Your Profile',
                            //text:'Updating your profile please wait a while.. ', 
                            // }),
                            if (progress == '100')    Swal.fire({
                                icon: 'success',
                                title: "Profile Updated",
                                text: "Your Profile Pucture Was Successfully Updated "
                            }), document.getElementById("cfilogsta1").innerHTML="Profile Picture Updated To New" 
                const userDocRefLA = firebase.firestore().collection('users').doc(firebase.auth().currentUser.uid);                                    userDocRefLA.update({ch25:"CFI:PROFILE PICTURE UPDATED"})
                document.getElementById("lpage").style.display="none"           
                        },
                        (error) => {
                            console.log(error)
        document.getElementById("lpage").style.display="none"                 
                            Swal.fire({
                                icon: 'error',
                                title: "Unable To Update Profile Picture",
                                text:error
                            })
                        },
                        () => {

                            uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                                console.log('File available at', downloadURL);
                                document.querySelector('#proimg').src = downloadURL
                    document.querySelector('#proimg3').src = downloadURL           
                                firebase.auth().currentUser.updateProfile({
                                    photoURL: downloadURL
                                })
                            });
                        }
                    );
                }  
                
  function uploadImageCs(e) {
     document.getElementById("lpage").style.display="block"              
      console.log(e.target.files[0]),
      
      document.getElementById("lpage").style.display="block", 
      
                        Swal.fire({
                            icon: 'info',
                            title: 'Uploading Your Profile',
                            text: 'Updating your profile please wait a while.. ',
                        })
                 
                    const uid = firebasee.auth().currentUser.uid
                    const fileRef = firebasee.storage().ref().child(`/users/${uid}/profileCs`)
                    const uploadTask = fileRef.put(e.target.files[0])
                    uploadTask.on('state_changed',
                        (snapshot) => {

                            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;

                            //icon:'info',
                            //title:'Uploading Your Profile',
                            //text:'Updating your profile please wait a while.. ', 
                            // }),
                            if (progress == '100')    Swal.fire({
                                icon: 'success',
                                title: "Profile Updated",
                                text: "Your Profile Pucture Was Successfully Updated "
                            }), document.getElementById("cfilogsta1").innerHTML="Profile Picture Updated To New" 
                
                document.getElementById("lpage").style.display="none"           
                        },
                        (error) => {
                            console.log(error)
        document.getElementById("lpage").style.display="none"                 
                            Swal.fire({
                                icon: 'error',
                                title: "Unable To Update Profile Picture",
                                text:error
                            })
                        },
                        () => {

                            uploadTask.snapshot.ref.getDownloadURL().then((downloadURLCS) => {
                                console.log('File available at', downloadURLCS);
                                document.querySelector('#proimgCs').src = downloadURLCS
                                firebasee.auth().currentUser.updateProfile({                        photoURL:downloadURLCS
                                })
                            });
                        }
                    );
                }                
                
                    
function restaccountFromCfi() {
  document.getElementById("restaccountCsCon").style.display = "none"
  
document.getElementById("restaccountCfiCon").style.display = "flex"
  document.getElementById("restaccountH1").innerHTML="Reset Account Data (Cloud Fire)"
   M.toast({
                        html: `CFIR:RestAccount Running For Cloud Fire`,
                        classes: "blue"
                    })
}
function uidshowFromCfi() {
     document.getElementById("uidshowCs").style.display="none"
     
document.getElementById("uidshowCfi").style.display="block"
     
document.getElementById("uidshowH1").innerHTML="UID CFI"     
document.getElementById("uidDesc").innerHTML="This is your permanent UID for CFI account activities, if you encountered any problems or bugs in ACCS or Cloud Fire International's other platforms contact us with this UID. please kept the UID secretly.."
 }

function updateUserProfiling(e) {
                    e.preventDefault()
                    const userDocRef = firebase.firestore()
                        .collection('users')
                        .doc(firebase.auth().currentUser.uid)


                    userDocRef.update({
                        vtype: editProfiling["usertag"].value,
                        vtypeco: editProfiling["usertagcolour"].value,
                        uid: editProfiling["uid_edit_internal"].value,
                        con: editProfiling["edit_accountclass_internal"].value,                   
                       chf:editProfiling["manualTHEME"].value,     

                    })

                    Swal.fire({
                        icon: "success",
                        title: "Update Succeed. ",
                        text: "Your UserTag Now Will Be Updated All Over The Platforms Of Cloud Fire International.",

                    })
                    const userDocRefLA = firebase.firestore().collection('users').doc(firebase.auth().currentUser.uid);                                    userDocRefLA.update({ch25:"USER TAGS UPDATED."})
                }
                
                function updateUserName(e) {
                    e.preventDefault()
                    const userDocRef = firebase.firestore()
                        .collection('users')
                        .doc(firebase.auth().currentUser.uid)


                    userDocRef.update({
                        name: editProfileName["name"].value,


                    })

                    Swal.fire({
                        icon: "success",
                        title: "Name was Changed ",
                        text: "Your Name Now Will Be Updated All Over The Platforms Of Cloud Fire International.",

                    })
                    const userDocRefLA = firebase.firestore().collection('users').doc(firebase.auth().currentUser.uid);                                    userDocRefLA.update({ch25:"CFI: USER NAME WAS UPDATED."})
                    //document.getElementById("modal14").style.diplay = "none"
                }


document.getElementById("lpage_t").innerHTML="<img src='img.384/Eclipse-1s-200px.gif' id='mainBootLoad'width='45px' height='45px'alt='L'></br>Connecting ACCS LITe</br><button onclick='endBload()' class='btn blue darken-2' id='devoption1'>End Boot Load!</button></br></br>"
window.addEventListener("load", function () {
    const lpagem = document.querySelector(".lpagem");
    lpagem.className += " hidden"; // class "lpagem hidden"
});
function endBload() {
const lpagem =
    document.querySelector(".lpagem");
    lpagem.className += " hidden";
}


document.getElementById("devoption1").style.display=""+devmode+""
document.getElementById("devoption2").style.display=""+devmode+""
document.getElementById("devoption3").style.display=""+devmode+""
document.getElementById("devoption4").style.display=""+devmode+""
document.getElementById("devoption5").style.display=""+devmode+""
document.getElementById("devoption6").style.display=""+devmode+""
document.getElementById("devoption7").style.display=""+devmode+""
document.getElementById("devoption8").style.display=""+devmode+""
document.getElementById("devoption9").style.display=""+devmode+""
document.getElementById("switch-3").style.display=""+devmode+""
document.getElementById("w22").style.display=""+devmode+""
document.getElementById("w23").style.display=""+devmode+""
document.getElementById("w24").style.display=""+devmode+""
//document.getElementById("tta").style.display=""+devmode+""
//document.getElementById("ttb").style.display=""+devmode+"", //document.getElementById("w31").style.display=""+devmode+"", document.getElementById("w32").style.display=""+devmode+"",  
document.getElementById("w34").style.display=""+devmode+"",
document.getElementById("w35").style.display=""+devmode+""
document.getElementById("BRDC_EN").style.display=""+devmode+""
console.warn("IMPORTED:- J CACHE ∞")
